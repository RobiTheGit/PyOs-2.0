import time
import subprocess

def clock():
    print('PyOs 2.0 Clock')
    print(time.ctime())
    time.sleep(1)
    subprocess.run('clear')
    clock()

clock()
