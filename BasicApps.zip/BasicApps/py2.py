import subprocess
py = input('Python2 File name(without extension): ')
try:
    subprocess.run(f'python2 {py}.py', shell=True)
except:
    subprocess.run(f'python {py}.py',shell=True)
