import webbrowser
webbrowser.open("https://google.com")
